Instruction:

1. input your database name, username, and password in db.ini (or enter the password manually each time)

2. create a schema named nsps

3. create tables named base, update, dlc

4. add columns title_id:char(16), game_title:varchar(100), version_num:varchar(40) to each table
